---
title: How It Works
page_title: our structured approach helps you navigate uncertainties


# perfomance
perfomance:
  - title: market profetionals
    description: Encourage frequent & timely recognition integrating with communication tools
    image: "/images/how-it-work/results.png"
  - title: measurable results
    description: Encourage frequent & timely recognition integrating with communication tools
    image: "/images/how-it-work/market-professionals.png"
  - title: international award
    description: Encourage frequent & timely recognition integrating with communication tools
    image: "/images/how-it-work/awards.png"
# works
our_works:
  - title: We'll do the legwork so you don't have to.
    image: "/images/how-it-work/image-1.png"
    list:
      - Supporting more than 119 country world
      - Open transaction with more than currencies
      - Customer Service with 79 languages
  - title: We'll do the legwork so you don't have to.
    image: "/images/how-it-work/image-2.png"
    list:
      - Supporting more than 119 country world
      - Open transaction with more than currencies
      - Customer Service with 79 languages
  - title: Check out their profiles, reviews On.
    image: "/images/how-it-work/image-3.png"
    list:
      - Supporting more than 119 country world
      - Open transaction with more than currencies
      - Customer Service with 79 languages
---
Donec sollicitudin molestie malesda. Donec sollitudin molestie malesuada. Mauris pellentesque <br /> nec, egestas non nisi. Cras ultricies ligula sed magna dictum porta.Lorem
